
<?php
include ("header.php"); 






?>




<div class="post_cat2">
    <div class="cat_bg2"> Program added Successful</div>
<h2>
<p>Your payment successful completed please wait 24 hours for activation if you have any question you can mail us at :   <font color="red"><br> <br>    <?php echo $support_email; ?></font>  </p>


 </h2>


    







</div>
<?php

include ("footer.php");


?>