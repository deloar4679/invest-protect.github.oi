
<?php
include ("header.php"); 






?>




<div class="post_cat2">
    <div class="cat_bg2"> Banner added Successful</div>
<h2>
<p>Your payment successful completed and banner added successful if you have any question you can mail us at :   <font color="red"><br> <br>    admin@investlister.com</font>  </p>


 </h2>


    







</div>
<?php

include ("footer.php");


?>