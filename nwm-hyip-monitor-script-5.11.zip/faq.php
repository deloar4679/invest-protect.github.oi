<?php
include ("header.php");
?>


<div class="post_cat2">
    <div class="cat_bg2"> SUPPORT FORM</div>
    
<h1>Questions</h1>
                <br />


<div class="articles">
<div class="item">
 <p style="font-style:italic;text-align:right;" class="date"></p>
 <p style="padding:10px 0 0 0;" class="text"><center><style>details summary::-webkit-details-marker {display: none;}details, summary {display: block;}.ssss1{background:#b3b3b3;box-shadow:inset 0px -11px 0px -8px rgba(0,0,0,0.1);width:100%;padding:5px 0px 5px 0px;color:#000;font-size:16px;font-weight:bold;text-align:center;display:inline-block;cursor:pointer;border-radius:50px;outline: none;}.ssss2{background:#E1E1E1;border-radius:25px;padding:10px;width:90%;margin-bottom:-15px;}</style><br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How I can get a refback?</summary>To receive the refback it is necessary to register on the project by going to it from our monitor. Then you should make your deposit and send a request through the special form on the site to receive it. You can do this by going into your account or using the form on the main page of monitor. After making a deposit in the project you selected, click on the link "Request RCB" in the project form, tell all the needed information. Then the amount of the referral commission will  be credited to you wallets. Refback is sent within 36 hours, but usually much earlier.<br />
  </details><br />
<br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How to order a return to the balance of the monitor?</summary>To order a refback on the balance of the monitor, you must select the payment system InvestLister in the form of a request RCB, indicating your login as a "Billing information".<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">What if the refback did not come?</summary>If within 72 hours you did not get a refback from our monitor, then you need to describe the problem in detail and contact SKYPE: InvestLister<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">"Personal Area" - why is it needed?</summary>After registration on monitor, you can order a refback on balance of monitor. Accumulated on the balance money, will bring 10% monthly. You can withdraw them at any time.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How to withdraw money from the balance of the personal area?</summary>To withdraw funds from the balance of the personal cabinet, you need to go through the authorization on our monitor and go to the "Withdraw Balance" tab. Next, select the payment system, specify the withdrawal amount and the current password from the you account. Then enter the confirmation code in the special form, which you will receive on your email and click the "Save" button.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How do I add wallets for payments?</summary>To specify purses for payments, you must go to your personal account and go to the "Personal Info" tab. After entering the details of the purses, you must specify the current password in the corresponding window, then enter the confirmation code, which you will receive on email and click the "Save" button.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">What if I do not receive the Confirmation Code?</summary>If the letter with the activation code doesn’t come to email address, you need to check the spam folder. If the message is not there, then contact the support chat on the main page of the monitor or SKYPE: InvestLister.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">What is a "Bag of Money"?</summary>"Bag of money" is a specially developed bonus system, which takes into account each refback ordered for the balance of monitoring. At the end of the month, the system automatically identifies the winners to receive 10% of all paid RCB for the month. A monthly «Bag of Money» is received by 6 users. The winners receive 50%, 25%, 10%, 7%, 5%, 3% as prizes.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How can I change email in my account?</summary>To ensure the security of your account, manual change of mail in your account is not possible. To change the email, contact the technical support service of the site, via chat on the main page or write to SKYPE: InvestLister.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">What is the difference between the listings (VIP, Exclusive, Premium, Normal, Trial)?</summary>The main difference between the listings is the amount of time and effort spent by the monitor administration to improve your project. So, for example, by ordering a Trial listing customer, receives the following services:<br />
•	Adding a project in a Trial section<br />
•	Expose a small Refback for your referrals<br />
Ordering the service Normal listing:<br />
•	Add the project into the regular section<br />
•	Set standard Refback for your referrals<br />
•	Set the statuses on the aggregators<br />
•	Support project 5 the main forums<br />
•	Mailing about the project on Skype chat monitoring.<br />
The advantages of the Normal listing service are obvious, but this is only a small part of our capabilities in relation to your project.When ordering the VIP Listing service, your project will get the maximum support and help from our monitor.<br />
•	Add the project in the best section<br />
•	Set the maximum Refback + bonuses for your referrals<br />
•	Contests and posts reviews news of your project for our referrals<br />
•	Set the statuses on the aggregators<br />
•	Support project on 25 forums<br />
•	Mailing about the project on Telegram chat monitoring and email monitoring participants (over 1600 people)<br />
•	Targeted e-mail newsletter to our database (100,000 contacts)<br />
•	Banner 728x90 on 21 days - as a gift<br />
•	Banner 160х600 on week - as a gift<br />
•	Video review on YouTube channel<br />
•	Text review<br />
•	Placement of project in our pinned topics in the forums<br />
•	Newsletter about the project in chat monitoring<br />
•	Project news on the main page of monitoring<br />
•	Status banner marked VIP on all aggregators<br />
•	Insurance of deposits in your project, the amount of the insurance Fund of $200<br />
•	Special VIP status at all aggregators<br />
To get acquainted with the prices and more detailed opportunities for each Listing plan, you need to click the button "Add project to monitoring" on the main page of the site.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How I can  find the project I need?</summary>To quickly find the desired project, you need to use the search engine, which is located in the upper right corner on the main page of the monitor. Entering the name of the project in the window, the system will immediately find it and display the information on the screen of your computer.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">I forgot the password from my personal cabinet, what should I do?</summary>To recover the password from the personal cabinet, on the authorization page, click the button "Forgot password?". After that, enter your email, which will be sent a letter with instructions for password recovery.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">What projects are safe?</summary>Although the administration of our monitor and tries to protect its users as much as possible, it is impossible to do it 100%. First of all we advise you to evaluate the project yourself and make a final decision on the contribution of your funds. To avoid losses, pay attention to the quality of the site, study user feedback from various sources. And remember: Don’t invest in Hyip what you can’t afford to lose!<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">How right to register in the project?</summary>To order a refund or insurance compensation it is necessary to register by clicking on our affiliate link. To do this, before you go to the site, you need to clean the cache and cookie files in your browser. After cleaning, go to the project you need from our monitor. Projects show your uplain, at registration, or after it in your account. Before making a deposit, be sure to check who is your upline.<br />
  </details><br />
  <br />
<details class="ssss2" style="color:black;"><br />
   <summary class="ssss1">Where to write about getting a refback?</summary>As an help to our monitor, we ask each user to write feedback about getting refback on forums and in social networks. A list of all the necessary links can be found on the main page.<br />
  </details><br />
  <br />
  <br />
</center></p>
</div>
<br>
</div></div>





<?php
include ("footer.php");
?>