


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="/templates/images/favicon.png" />
<title><?php echo $site_title ;?></title>
<meta name="description" content="<?php echo $description ;?>" />
<meta name="keywords" content="<?php echo $keywords ;?>" />
<script src='https://www.google.com/recaptcha/api.js'></script>
<link href="../templates//css/global.css" rel="stylesheet" type="text/css" />
<link href="../templates/css/site.css" rel="stylesheet" type="text/css" />
<link href="../templates/css/style.css" rel="stylesheet" type="text/css" />
<link href="../templates/css/animations.css" rel="stylesheet" type="text/css" />
<link href="../templates/css/programs.css" rel="stylesheet" type="text/css" />





	
</head>
<body>

<!-- start BG -->
<div id="bg"></div>
<!-- end BG -->

<!-- start WRAP -->
<div id="wrap">
	<!-- start HEADER -->
	<div id="header">
		<!--<a href="index.php?view=home" class="logo-top"></a>-->
		<a href="/" class="logo"></a>
		
	</div>
	<!-- end HEADER --><div class="clear"></div>
		
	<div class="clear"></div><br>
	<!-- start MAIN -->
	<div id="main">
	
	




















<div class="post_cat2">
    <div class="cat_bg2"> INSTALLATION OF NEM HYIP LISTER</div>
<h4>
Support contact Email :  newwebmaker.com@gmail.com </h4>


    
<form action="insert.php" method="post">

        <table >
      
         <tr>
          <td>Host Name: </td>
          <td><input type="text" name="dbhost" value="localhost" placeholder="localhost"> </td>
         </tr>	
          <tr>
          <td>Database Username: </td>
          <td><input type="text" name="dbuser" > </td>
         </tr>
       	
         <tr>
          <td>Database Password: </td>
          <td><input type="text" name="dbpassword"  > </td>
         </tr>
     
           <tr>
          <td>Database Name: </td>
          <td><input type="text" name="dbname"  > </td>
         </tr>
         
         
        
        
        
         
         
         <tr align="center"><td colspan="2"><input type="submit" name="install"  ></td> </tr>

        
        </table> 	

     </form>



</div>


