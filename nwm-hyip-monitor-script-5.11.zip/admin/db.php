<?php

include ('../config/db.php');
?>