 <a href="http://www.EarnUpdates.com/?key=<?php echo $pro_url; ?>&lid=<?php echo $pro_id; ?>&ref=investlister.com" target="_blank"><img src="templates/images/am_s.jpg" alt="EarnUpdates.com" title="EarnUpdates.com" /></a>
                            
                             <a href="http://allmonitors24.com/index/search?search=<?php echo $pro_url; ?>" target="_blank"><img src="templates/images/logotop.gif" border="0" width="16" height="16" /></a>
                             
                              <a target="_blank" href="http://allhyipmon.ru/monitor/<?php echo $pro_url; ?>" ahmdis="<?php echo $pro_id; ?>"><img src="templates/images/ru.png"></a>
                             
                            
                             
                             
                             <a href="http://www.allhyipmonitors.com/search/?keyword=<?php echo $pro_url ; ?>&status=<?php echo $status; ?>&lid=<?php echo $pro_id; ?>&ref=investlister.com" target="_blank"><img align="top" src="templates/images/ahmlogo.png" width="16" height="16" ></a> 
                              
                             <a target="_blank" href="http://allmonitors.net/hyip/<?php echo $pro_url; ?>/fav1129"><img align="top" src="templates/images/allmonitors.gif" width="16" height="16" ></a>
                            
                            <a href="http://www.allmon.biz/?key=<?php echo $pro_url; ?>&lid=<?php echo $pro_id; ?>&ref=investlister.com" target="blank"><img src="templates/images/allmonbiz.jpg" alt="AllMon.biz" title="AllMon.biz" /></a>
                            
                            <a href="http://monitors.bz/?key=<?php echo $pro_url; ?>&lid=<?php echo $pro_id; ?>&ref=investlister.com" target="blank"><img src="templates/images/monitorsbz.png" alt="monitors.bz" title="monitors.bz" /></a>
                            
                            <a href="http://58hyip.com/search.php?keyword= <?php echo $pro_url; ?>&status=<?php echo $status; ?>&lid=<?php echo $pro_id; ?>&ref=investlister.com" target="blank"><img src="templates/images/58hyip.png" alt="58hyip.com" title="58hyip.com" /></a>
                            
                            <a target="_blank" href="http://hyiplisters.com/h/<?php echo $pro_url; ?>" title="HyipListers"><img align="top" src="templates/images/hyiplisters.png" title="Hyiplisters.com" width="16px" height="16px"></a>
                            
                            
                            
                            <a target="_blank" href="https://hyiplogs.com/project/<?php echo $pro_url; ?>"><img align="top" src="templates/images/s_icon.png" title="HyipLogs" style="width:16px; height:16px;"></a>
                            
                            <a href="http://InvestorsStartPage.com/check/d/<?php echo $pro_url; ?>/r/investlister.net" target="_blank">
<img align="top" src="templates/images/isp.png" title="InvestorsStartPage.com" width="16px" height="16px"></a>

<a href="http://hyip-zanoza.me/en/program/<?php echo $pro_url; ?>" title="Detailed analysis and reviews HYIP project REDEARN" target="_blank"><img title="Detailed analysis and reviews HYIP project REDEARN" alt="Detailed analysis and reviews HYIP project REDEARN" src="https://hyip-zanoza.me/images/mini_icon.gif"></a>

<a target="_blank" href="http://www.hyip.biz/details/<?php echo $pro_url; ?>">
<img src="https://www.hyip.biz/informer/<?php echo $pro_url; ?>" border="0" alt="HYIP.biz"></a>
                            
                            
                            
                            
                            
                            
                         
                            
                           
                            
                     