
<?php
include ("header.php");
include ("hot.php");
include ("footer.php");


?>