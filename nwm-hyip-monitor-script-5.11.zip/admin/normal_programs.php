<?php
include ("header.php");
include ("normal.php");
include ("footer.php");


?>