<?php
include ("header.php");

?>


<!-- start ACCOUNTBOX -->
			<div class="accountBox">
			
			
				
<div class="post_cat">
    <div class="cat_bg"> GENERAL SETTINGS</div>
			
				
			
				
				<!-- start BOX -->
				<div class="box" id="summary">
				
		
					<!-- start STATS -->
					<div class="stats left">
					
						<p class="title"> SITE SETTINGS</p>
						
						<table cellpadding="0" cellspacing="0">
					
													<tr>
								<td>MAIN SETTINGS:</td>
								<td class="value"><a href="main_settings.php" class="ad-btn2">EDIT</a></td>
							</tr>
							
								
																				
													</table>
											
													<hr>
														<table cellpadding="0" cellspacing="0">
					
													<tr>
								<td>Admin Account Settings:</td>
								<td class="value"><a href="admin_settings.php" class="ad-btn2">EDIT</a></td>
							</tr>
								
																				
													</table>
													<hr>
					
					</div>
					<!-- end STATS -->
					
					
					<!-- start STATS -->
					<div class="stats left">
					
						<p class="title"> PAYMENT ACCOUNTS SETUP</p>
						
						<table cellpadding="0" cellspacing="0">
					
													<tr>
								<td>MSP MySidePay:</td>
								<td class="value"><a href="edit_msp.php" class="ad-btn2">EDIT</a></td>
							</tr>
								
																				
													</table>
													<hr>
													
													
													
														<table cellpadding="0" cellspacing="0">
					
							
								
														<tr>
								<td>PerfectMoney:</td>
								<td class="value"><a href="edit_pm.php" class="ad-btn2">EDIT</a></td>
							</tr>
																					
																											
													</table>
													<hr>
													
													
														<table cellpadding="0" cellspacing="0">
					
																					
																					<tr>
								<td>Payeer:</td>
								<td class="value"><a href="edit_payeer.php" class="ad-btn2">EDIT</a></td>
							</tr>
																										
													</table>
													<hr>
													
														<table cellpadding="0" cellspacing="0">
					
																			<tr>
								<td>Bitcoin: </td>
								<td class="value"><a href="edit_btc.php" class="ad-btn2">EDIT</a></td>
							</tr>
																		
													</table>
													<hr>
														<table cellpadding="0" cellspacing="0">
					
					
									
										<tr>
								<td>ADV CASH: </td>
								<td class="value"><a href="edit_advcash.php" class="ad-btn2">EDIT</a></td>
							</tr>												
													</table>
													<hr>
					
					</div>
					<!-- end STATS -->
					
				
				
					<div class="clr"></div>
					
					<!-- end STATS -->
					
					<div class="clr"></div>
					
					
				
					
				
			
			</div></div>
			<!-- end ACCOUNTBOX -->
</div>
<?php


include ("footer.php");


?>