
<?php
include ("header.php");
include ("scam.php");
include ("footer.php");


?>