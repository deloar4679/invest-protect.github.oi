

</div>

<!-- start FOOTER -->
		<div id="footer">
		
			<!-- start LINKS -->
			<ul class="links">
			
			
	<li><a href="/">Go to user Area</a></li>		
			</ul>
			<!-- end LINKS -->
			
			<!-- start RIGHT -->
			<div class="right">
			
			<p class="copy"></p>
				<p class="designer">&bull; &nbsp; &nbsp; Design by <a href="https://www.newwebmaker.com/" target="_blank">NEW WEB MAKER</a>.</p>
				<div class="script">Software Developed By <a href="http://newwebmaker.com/" target="_blank">NewWebMaker</a></div>
				
				<div class="clr"></div>
			
			</div>
			<!-- end RIGHT -->
			
			<div class="clr"></div>
		
		</div>
		<!-- end FOOTER -->
	
	</div>
	<!-- end MAIN -->

</div>
<!-- end WRAP -->

</body>
    </html>
