
<?php
include ("../db.php"); 

Header('Location: https://investlister.com/payment_fail.php');
                          
                          




?>










